<?php
session_start();
require_once '../modelo/usuario.php';

class AutenControlador {
    public function login($documento, $password) {
        $usuario = new Usuario();
        $userData = $usuario->buscarPorDocumento($documento);

        // Verificamos que el usuario existe y la contraseña coincide
        if ($userData && $password === $userData['password']) {
            $_SESSION['usuario'] = $userData; // Guardamos datos del usuario en la sesión
            
            // Redirigir según el rol
            switch ($userData['rol']) {
                case 'administrador':
                    header("Location: ../vista/panel_admin.php");
                    break;
                case 'medico':
                    header("Location: ../vista/panel_medico.php");
                    break;
                case 'paciente':
                    header("Location: ../vista/panel_paciente.php");
                    break;
                default:
                    echo "Rol no válido.";
                    break;
            }
        } else {
            echo "Usuario o contraseña incorrectos.";
        }
    }

    public function logout() {
        session_destroy();
        header("Location: ../vista/login.php");
    }
}

// Verifica si el formulario de login fue enviado
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $controlador = new AutenControlador();
    $controlador->login($_POST['numero_documento'], $_POST['password']);
}
?>
