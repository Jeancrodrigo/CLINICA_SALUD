<?php
session_start();

if (!isset($_SESSION['usuario']) || $_SESSION['usuario']['rol'] !== 'paciente') {
    header("Location: login.php");
    exit();
}

$conexion = new mysqli("localhost", "root", "", "proyecto_web");
$id_paciente = $_SESSION['usuario']['id_usuario'];

// Obtener citas del paciente
$citas = $conexion->query("
  SELECT c.fecha_hora, m.nombre AS nombre_medico, m.apellido AS apellido_medico
  FROM citas c
  JOIN medico m ON c.id_medico = m.id_medico
  WHERE c.id_paciente = $id_paciente
");
?>

<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Mis Citas</title>
</head>
<body>
  <h1>Mis Citas</h1>
  <table>
    <thead>
      <tr>
        <th>Fecha y Hora</th>
        <th>Médico</th>
      </tr>
    </thead>
    <tbody>
      <?php while ($row = $citas->fetch_assoc()): ?>
        <tr>
          <td><?= $row['fecha_hora']; ?></td>
          <td><?= $row['nombre_medico'] . ' ' . $row['apellido_medico']; ?></td>
        </tr>
      <?php endwhile; ?>
    </tbody>
  </table>
</body>
</html>
