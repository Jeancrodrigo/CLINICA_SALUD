<?php
require_once '../modelo/usuario.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $tipo_documento = $_POST['tipo_documento'];
    $numero_documento = $_POST['numero_documento'];
    $nombre = $_POST['nombre'];
    $apellido_paterno = $_POST['apellido_paterno'];
    $apellido_materno = $_POST['apellido_materno'];
    $fecha_nacimiento = $_POST['fecha_nacimiento'];
    $celular = $_POST['celular'];
    $correo = $_POST['correo'];
    $genero = $_POST['genero'];
    $departamento = $_POST['departamento'];
    $provincia = $_POST['provincia'];
    $distrito = $_POST['distrito'];
    $direccion = $_POST['direccion'];
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];

    // Validar que las contraseñas coincidan
    if ($password !== $confirm_password) {
        echo "Las contraseñas no coinciden. <a href='../vista/registro.php'>Volver</a>";
        exit();
    }

    // Crear el objeto Usuario y registrar
    $usuario = new Usuario();
    $resultado = $usuario->registrarUsuarioCompleto(
        $tipo_documento, $numero_documento, $nombre, $apellido_paterno, 
        $apellido_materno, $fecha_nacimiento, $celular, $correo, $genero, 
        $departamento, $provincia, $distrito, $direccion, $password, 'paciente'
    );

    if ($resultado) {
        // Redirigir a la confirmación
        header("Location: ../vista/confirmacion_reg.php");
        exit();
    } else {
        echo "Error al registrar el usuario. <a href='../vista/registro.php'>Volver</a>";
    }
}
?>
