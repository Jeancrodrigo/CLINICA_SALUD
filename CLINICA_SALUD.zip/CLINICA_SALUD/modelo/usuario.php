<?php
class Usuario {
    private $conexion;

    public function __construct() {
        $this->conexion = new mysqli("localhost", "root", "", "proyecto_web");
        if ($this->conexion->connect_error) {
            die("Error de conexión a la base de datos: " . $this->conexion->connect_error);
        }
    }
    public function buscarPorDocumento($documento) {
        $stmt = $this->conexion->prepare("SELECT * FROM usuarios WHERE numero_documento = ?");
        $stmt->bind_param("s", $documento); // 's' indica que el parámetro es una cadena
        $stmt->execute();
        $resultado = $stmt->get_result();
        
        // Si existe el usuario, retornamos los datos, si no, retornamos null
        if ($resultado->num_rows > 0) {
            return $resultado->fetch_assoc(); // Devuelve los datos del usuario
        } else {
            return null; // Usuario no encontrado
        }
    }   

    public function registrarUsuarioCompleto(
        $tipo_documento, $numero_documento, $nombre, $apellido_paterno, 
        $apellido_materno, $fecha_nacimiento, $celular, $correo, $genero, 
        $departamento, $provincia, $distrito, $direccion, $password, $rol
    ) {
        $stmt = $this->conexion->prepare("
            INSERT INTO usuarios (
                tipo_documento, numero_documento, nombre, apellido_paterno, 
                apellido_materno, fecha_nacimiento, celular, correo, genero, 
                departamento, provincia, distrito, direccion, password, rol
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ");

        $stmt->bind_param(
            "sssssssssssssss", 
            $tipo_documento, $numero_documento, $nombre, $apellido_paterno, 
            $apellido_materno, $fecha_nacimiento, $celular, $correo, $genero, 
            $departamento, $provincia, $distrito, $direccion, $password, $rol
        );

        return $stmt->execute();
    }
}
?>

?>
