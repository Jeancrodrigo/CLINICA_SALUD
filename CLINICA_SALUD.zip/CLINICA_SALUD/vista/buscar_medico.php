<?php
$conexion = new mysqli("localhost", "root", "", "proyecto_web");

$search = $_GET['search'] ?? '';

// Buscar médicos
$medicos = $conexion->query("
  SELECT nombre, apellido 
  FROM medico 
  WHERE nombre LIKE '%$search%' OR apellido LIKE '%$search%'
");
?>

<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Buscar Médico</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      padding: 20px;
      background: url('background-pattern.png') no-repeat center center fixed;
      background-size: cover;
    }

    .container {
      background-color: #fff;
      padding: 2rem;
      border-radius: 10px;
      box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
    }

    h1 {
      text-align: center;
      color: #007bff;
    }

    form {
      margin-bottom: 1rem;
    }

    input, button {
      padding: 10px;
      margin-right: 10px;
      border: 1px solid #ccc;
      border-radius: 5px;
    }

    table {
      width: 100%;
      border-collapse: collapse;
    }

    th, td {
      padding: 10px;
      border: 1px solid #ddd;
    }

    th {
      background-color: #007bff;
      color: #fff;
    }
  </style>
</head>
<body>
  <div class="container">
    <h1>Buscar Médico</h1>
    <form method="GET" action="buscar_medico.php">
      <input type="text" name="search" placeholder="Escribe el nombre del médico" value="<?= $search; ?>">
      <button type="submit">Buscar</button>
    </form>
    <table>
      <thead>
        <tr>
          <th>Nombre</th>
        </tr>
      </thead>
      <tbody>
        <?php while ($row = $medicos->fetch_assoc()): ?>
          <tr>
            <td><?= $row['nombre'] . ' ' . $row['apellido']; ?></td>
          </tr>
        <?php endwhile; ?>
      </tbody>
    </table>
  </div>
</body>
</html>
