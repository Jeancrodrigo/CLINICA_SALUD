<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Registro - Clínica Salud</title>
  <style>
    /* Estilos principales incluidos aquí */
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
      font-family: Arial, sans-serif;
    }

    body {
      display: flex;
      justify-content: center;
      align-items: center;
      height: 100vh;
      background: #f8f9fc url('background-pattern.png') repeat;
      color: #333;
    }

    .back-button {
      position: absolute;
      top: 1rem;
      left: 1rem;
      background-color: #005ea6;
      color: #fff;
      padding: 0.5rem 1rem;
      border: none;
      border-radius: 5px;
      cursor: pointer;
      font-size: 1rem;
    }

    .back-button:hover {
      background-color: #004080;
    }

    .form-container {
      background-color: #ffffff;
      padding: 2rem;
      border-radius: 10px;
      box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
      width: 90%;
      max-width: 900px;
    }

    .form-header {
      text-align: center;
      margin-bottom: 1.5rem;
    }

    .form-header h2 {
      font-size: 2rem;
      color: #005ea6;
      margin-bottom: 0.5rem;
    }

    .form-header h3 {
      font-size: 1rem;
      color: #48b1bf;
    }

    .form-group {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 1rem;
      margin-bottom: 1rem;
    }

    .form-group label {
      display: block;
      font-size: 0.9rem;
      color: #333;
      margin-bottom: 0.5rem;
    }

    .form-group input,
    .form-group select {
      width: 100%;
      padding: 0.8rem;
      border: 1px solid #ccc;
      border-radius: 5px;
      font-size: 1rem;
    }

    .radio-group {
      display: flex;
      gap: 1rem;
      margin-bottom: 1rem;
    }

    .radio-group label {
      font-size: 0.9rem;
      color: #333;
    }

    .form-button {
      text-align: center;
      margin-top: 1rem;
    }

    .form-button button {
      padding: 0.8rem 2rem;
      background-color: #0033a0;
      color: #fff;
      border: none;
      border-radius: 5px;
      font-size: 1rem;
      cursor: pointer;
    }

    .form-button button:hover {
      background-color: #002275;
    }
  </style>
</head>
<body>
  <button class="back-button" onclick="history.back()">Regresar</button>
  <div class="form-container">
    <div class="form-header">
      <h2>Registro</h2>
      <h3>Ingresa tus datos</h3>
    </div>
    <form action="../controlador/register_process.php" method="POST">
      <div class="radio-group">
        <label><input type="radio" name="tipo_documento" value="DNI" checked> DNI</label>
        <label><input type="radio" name="tipo_documento" value="CE"> CE</label>
        <label><input type="radio" name="tipo_documento" value="Pasaporte"> Pasaporte</label>
      </div>
      <div class="form-group">
        <div>
          <label for="numero_documento">Número de documento*</label>
          <input type="text" id="numero_documento" name="numero_documento" placeholder="Número de documento" required>
        </div>
        <div>
          <label for="fecha_nacimiento">Fecha de nacimiento*</label>
          <input type="date" id="fecha_nacimiento" name="fecha_nacimiento" required>
        </div>
        <div>
          <label for="nombre">Nombre*</label>
          <input type="text" id="nombre" name="nombre" placeholder="Nombre" required>
        </div>
        <div>
          <label for="apellido_paterno">Apellido paterno*</label>
          <input type="text" id="apellido_paterno" name="apellido_paterno" placeholder="Apellido paterno" required>
        </div>
        <div>
          <label for="apellido_materno">Apellido materno*</label>
          <input type="text" id="apellido_materno" name="apellido_materno" placeholder="Apellido materno" required>
        </div>
        <div>
          <label for="genero">Género*</label>
          <select id="genero" name="genero" required>
            <option value="">Seleccionar</option>
            <option value="Masculino">Masculino</option>
            <option value="Femenino">Femenino</option>
            <option value="Otro">Otro</option>
          </select>
        </div>
        <div>
          <label for="celular">Celular*</label>
          <input type="tel" id="celular" name="celular" placeholder="Número de celular" required>
        </div>
        <div>
          <label for="correo">Correo electrónico*</label>
          <input type="email" id="correo" name="correo" placeholder="Correo electrónico" required>
        </div>
        
        <div>
  <label for="departamento">Departamento*</label>
  <input type="text" id="departamento" name="departamento" placeholder="Escribe tu departamento" required>
</div>
<div>
  <label for="provincia">Provincia*</label>
  <input type="text" id="provincia" name="provincia" placeholder="Escribe tu provincia" required>
</div>
<div>
  <label for="distrito">Distrito*</label>
  <input type="text" id="distrito" name="distrito" placeholder="Escribe tu distrito" required>
</div>

        <div>
          <label for="direccion">Dirección del paciente*</label>
          <input type="text" id="direccion" name="direccion" placeholder="Dirección" required>
        </div>
        <div>
          <label for="password">Contraseña*</label>
          <input type="password" id="password" name="password" placeholder="Contraseña" required>
        </div>
        <div>
          <label for="confirm_password">Confirmar contraseña*</label>
          <input type="password" id="confirm_password" name="confirm_password" placeholder="Confirmar contraseña" required>
        </div>
      </div>
      <div class="form-button">
        <button type="submit">Registrar</button>
      </div>
    </form>
  </div>
</body>
</html>
