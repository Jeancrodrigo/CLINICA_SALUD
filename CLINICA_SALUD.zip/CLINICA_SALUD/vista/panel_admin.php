<?php
session_start();
require_once '../modelo/usuario.php';

// Verificar si el usuario es administrador
if (!isset($_SESSION['usuario']) || $_SESSION['usuario']['rol'] !== 'administrador') {
    header("Location: login.php");
    exit();
}

// Conexión a la base de datos
$conexion = new mysqli("localhost", "root", "", "proyecto_web");
if ($conexion->connect_error) {
    die("Error de conexión: " . $conexion->connect_error);
}

// Obtener la lista de usuarios
$query = "SELECT id_usuario, nombre, apellido_paterno, correo, rol FROM usuarios";
$result = $conexion->query($query);

// Verificar si se envió un cambio de rol
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['id_usuario']) && isset($_POST['rol'])) {
    $id_usuario = $_POST['id_usuario'];
    $nuevo_rol = $_POST['rol'];

    $stmt = $conexion->prepare("UPDATE usuarios SET rol = ? WHERE id_usuario = ?");
    $stmt->bind_param("si", $nuevo_rol, $id_usuario);
    if ($stmt->execute()) {
        $mensaje = "Rol actualizado correctamente.";
    } else {
        $mensaje = "Error al actualizar el rol.";
    }
    $stmt->close();
    // Recargar para reflejar los cambios
    header("Location: panel_admin.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Panel de Administración</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f2f2f2;
            margin: 20px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }
        table, th, td {
            border: 1px solid #ddd;
        }
        th, td {
            padding: 10px;
            text-align: left;
        }
        th {
            background-color: #2c3e50;
            color: white;
        }
        .btn {
            padding: 5px 10px;
            background-color: #3498db;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        .btn:hover {
            background-color: #2980b9;
        }
        .form-select {
            padding: 5px;
            border: 1px solid #ddd;
            border-radius: 5px;
        }
    </style>
</head>
<body>
    <h1>Panel de Administración</h1>
    <h2>Gestión de Roles</h2>

    <?php if (isset($mensaje)): ?>
        <p><?= $mensaje; ?></p>
    <?php endif; ?>

    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Nombre</th>
                <th>Correo</th>
                <th>Rol Actual</th>
                <th>Asignar Nuevo Rol</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($usuario = $result->fetch_assoc()): ?>
                <tr>
                    <td><?= $usuario['id_usuario']; ?></td>
                    <td><?= $usuario['nombre'] . ' ' . $usuario['apellido_paterno']; ?></td>
                    <td><?= $usuario['correo']; ?></td>
                    <td><?= $usuario['rol']; ?></td>
                    <td>
                        <form action="panel_admin.php" method="POST" style="display: flex; align-items: center;">
                            <input type="hidden" name="id_usuario" value="<?= $usuario['id_usuario']; ?>">
                            <select name="rol" class="form-select">
                                <option value="paciente" <?= $usuario['rol'] === 'paciente' ? 'selected' : ''; ?>>Paciente</option>
                                <option value="medico" <?= $usuario['rol'] === 'medico' ? 'selected' : ''; ?>>Médico</option>
                                <option value="administrador" <?= $usuario['rol'] === 'administrador' ? 'selected' : ''; ?>>Administrador</option>
                            </select>
                            <button type="submit" class="btn">Actualizar</button>
                        </form>
                    </td>
                </tr>
            <?php endwhile; ?>
        </tbody>
    </table>
</body>
</html>
