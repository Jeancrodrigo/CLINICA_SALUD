<?php
session_start();

// Verificamos si el usuario ha iniciado sesión y es paciente
if (!isset($_SESSION['usuario']) || $_SESSION['usuario']['rol'] !== 'paciente') {
    header("Location: login.php");
    exit();
}

// Conexión a la base de datos
$conexion = new mysqli("localhost", "root", "", "proyecto_web");
if ($conexion->connect_error) {
    die("Error de conexión: " . $conexion->connect_error);
}

// Obtener las citas del paciente
$id_paciente = $_SESSION['usuario']['id_usuario'];
$query = "SELECT c.id_cita, c.fecha_hora, c.motivo, 
                 m.nombre AS nombre_medico, m.apellido AS apellido_medico, 
                 m.especialidad 
          FROM citas c
          JOIN medico m ON c.id_medico = m.id_medico
          WHERE c.id_paciente = ?";
$stmt = $conexion->prepare($query);
$stmt->bind_param("i", $id_paciente);
$stmt->execute();
$result = $stmt->get_result();
?>

<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Clínica Salud - Portal del Paciente</title>
  <style>
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
      font-family: Arial, sans-serif;
    }

    body {
      background: #f8f9fc;
      color: #333;
    }

    header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 10px 20px;
      background-color: #fff;
      border-bottom: 1px solid #ddd;
    }

    .logo {
      display: flex;
      align-items: center;
    }

    .logo img {
      height: 50px;
      margin-right: 10px;
    }

    .logo h1 {
      font-size: 1.5rem;
      margin-bottom: 0.2rem;
    }

    .logo p {
      font-size: 0.9rem;
      color: #666;
    }

    nav ul {
      display: flex;
      list-style: none;
    }

    nav ul li {
      margin-left: 20px;
    }

    nav ul li a {
      text-decoration: none;
      color: #007bff;
      font-weight: bold;
      font-size: 1rem;
    }

    nav ul li a:hover {
      text-decoration: underline;
    }

    main {
      text-align: center;
      padding: 20px;
    }

    .welcome h2 {
      font-size: 2rem;
      color: #007bff;
      margin-bottom: 20px;
    }

    .cards {
      display: flex;
      justify-content: center;
      gap: 20px;
      margin-top: 30px;
    }

    .card {
      background: #eef4fc;
      border-radius: 8px;
      padding: 20px;
      width: 200px;
      text-align: center;
      box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
    }

    .card .icon {
      font-size: 3rem;
      margin-bottom: 10px;
      color: #007bff;
    }

    .card h3 {
      font-size: 1.2rem;
      color: #333;
    }

    .card:hover {
      background: #d9e6fa;
      cursor: pointer;
    }

    .card a {
      text-decoration: none;
      color: inherit;
    }
  </style>
</head>
<body>
  <header>
    <div class="logo">
      <img src="logo.png" alt="Clínica Salud">
      <h1>Clínica Salud</h1>
      <p>Portal del Paciente</p>
    </div>
    <nav>
      <ul>
        <li><a href="panel_paciente.php">Inicio</a></li>
        <li><a href="agenda_cita.php">Agenda una cita</a></li>
        <li><a href="historial_medico.php">Mi historial médico</a></li>
        <li><a href="logout.php">Cerrar sesión</a></li>
      </ul>
    </nav>
  </header>

  <main>
    <section class="welcome">
      <h2>Hola, <?= $_SESSION['usuario']['nombre']; ?>. Bienvenid@ a tu clínica</h2>
    </section>

    <section class="cards">
      <div class="card">
        <a href="agenda_cita.php">
          <div class="icon">📅</div>
          <h3>Agenda una cita</h3>
        </a>
      </div>
      <div class="card">
        <a href="mis_citas.php">
          <div class="icon">📲</div>
          <h3>Mis citas</h3>
        </a>
      </div>
      <div class="card">
        <a href="buscar_medico.php">
          <div class="icon">🔍</div>
          <h3>Busca a tu médico</h3>
        </a>
      </div>
    </section>
  </main>
</body>
</html>