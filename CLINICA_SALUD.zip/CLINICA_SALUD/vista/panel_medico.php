<?php
session_start();
require_once '../modelo/usuario.php';

// Verifica si el usuario tiene rol de médico
if (!isset($_SESSION['usuario']) || $_SESSION['usuario']['rol'] !== 'medico') {
    header("Location: login.php");
    exit();
}

// Conexión a la base de datos
$conexion = new mysqli("localhost", "root", "", "proyecto_web");
if ($conexion->connect_error) {
    die("Error de conexión: " . $conexion->connect_error);
}

// Obtener citas del médico
$id_medico = $_SESSION['usuario']['id_usuario'];
$query = "SELECT c.id_cita, c.fecha_hora, c.motivo, p.nombre AS paciente_nombre, p.apellido AS paciente_apellido 
          FROM citas c 
          JOIN pacientes p ON c.id_paciente = p.id_paciente 
          WHERE c.id_medico = ? AND c.fecha_hora >= NOW()"; // Solo citas futuras
$stmt = $conexion->prepare($query);
$stmt->bind_param("i", $id_medico);
$stmt->execute();
$result = $stmt->get_result();

// Convertir resultados a formato JSON para FullCalendar
$citas = [];
while ($row = $result->fetch_assoc()) {
    // Añadir las citas al array en formato que FullCalendar espera
    $citas[] = [
        'title' => $row['motivo'] . ' - ' . $row['paciente_nombre'] . ' ' . $row['paciente_apellido'],
        'start' => $row['fecha_hora'],
        'end' => date('Y-m-d H:i:s', strtotime($row['fecha_hora'] . ' +1 hour')), // Asignar una duración de 1 hora
    ];
}
$jsonCitas = json_encode($citas);
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Panel Médico</title>
    <!-- FullCalendar CSS -->
    <link href="https://cdn.jsdelivr.net/npm/fullcalendar@6.1.8/index.global.min.css" rel="stylesheet">
    <!-- FullCalendar JS -->
    <script src="https://cdn.jsdelivr.net/npm/fullcalendar@6.1.8/index.global.min.js"></script>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
        }

        #calendar {
            max-width: 900px;
            margin: 0 auto;
        }

        .fc-event {
            background-color: #007bff !important;
            color: white !important;
            border-radius: 5px;
            padding: 5px;
        }

        .fc-event:hover {
            background-color: #0056b3 !important;
        }

        .fc-header-toolbar {
            background-color: #f8f9fc;
            border-bottom: 2px solid #ddd;
        }

        .fc-daygrid-day-number {
            font-weight: bold;
        }

        h1, h2 {
            color: #007bff;
        }
    </style>
</head>
<body>
    <h1>Bienvenido, Dr. <?= $_SESSION['usuario']['nombre']; ?></h1>
    <h2>Calendario de Citas</h2>
    <div id="calendar"></div>

    <script>
        document.addEventListener('DOMContentLoaded', function () {
            const calendarEl = document.getElementById('calendar');
            const calendar = new FullCalendar.Calendar(calendarEl, {
                initialView: 'dayGridMonth',
                headerToolbar: {
                    left: 'prev,next today',
                    center: 'title',
                    right: 'dayGridMonth,timeGridWeek,timeGridDay'
                },
                events: <?= $jsonCitas; ?>, // Citas desde PHP
                locale: 'es', // Español
                eventRender: function(info) {
                    // Ajustar cómo se muestra el evento en el calendario
                    info.el.querySelector('.fc-event-title').innerHTML = info.event.title + '<br>' + info.event.start.toLocaleTimeString();
                },
                eventClick: function(info) {
                    alert('Cita: ' + info.event.title + '\nFecha y Hora: ' + info.event.start.toLocaleString());
                }
            });
            calendar.render();
        });
    </script>
</body>
</html>
