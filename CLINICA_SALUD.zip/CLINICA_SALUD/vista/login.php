<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Clínica Salud - Iniciar Sesión</title>
  <style>
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
      font-family: Arial, sans-serif;
    }

    body {
      display: flex;
      height: 100vh;
    }

    .left-panel {
      width: 60%;
      background-color: #d0f0f2;
      color: #005ea6;
      padding: 4rem;
    }

    .left-panel h1 {
      font-size: 7rem;
      line-height: 1.2;
      margin-bottom: 1.5rem;
      font-style: italic;
    }

    .left-panel h1 span {
      font-weight: bold;
    }

    .left-panel p {
      font-size: 1.5rem;
      margin-top: 1rem;
    }

    .right-panel {
      width: 40%;
      background-color: #fdeff0;
      display: flex;
      flex-direction: column;
      justify-content: center;
      align-items: center;
      padding: 2rem;
    }

    .right-panel form {
      background-color: #fff;
      padding: 2rem;
      border-radius: 10px;
      box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
      width: 100%;
      max-width: 400px;
      margin-bottom: 1rem;
    }

    .right-panel h2 {
      margin-bottom: 1rem;
      font-size: 1.5rem;
      color: #333;
    }

    .right-panel form label {
      display: block;
      margin-bottom: 0.5rem;
      font-size: 0.9rem;
      color: #555;
    }

    .right-panel form input[type="text"],
    .right-panel form input[type="password"] {
      width: 100%;
      padding: 0.8rem;
      margin-bottom: 1rem;
      border: 1px solid #ccc;
      border-radius: 5px;
      font-size: 1rem;
    }

    .right-panel form button {
      width: 100%;
      padding: 0.8rem;
      background-color: #0033a0;
      color: #fff;
      border: none;
      border-radius: 5px;
      font-size: 1rem;
      cursor: pointer;
    }

    .right-panel form button:hover {
      background-color: #002275;
    }

    .right-panel .links {
      display: flex;
      justify-content: center;
      gap: 1rem; /* Espacio entre los botones */
      margin-top: 1rem;
    }

    .right-panel .links button {
      padding: 0.8rem 1.5rem;
      background-color: #fff;
      color: #0033a0;
      border: 2px solid #0033a0;
      border-radius: 5px;
      font-size: 1rem;
      font-weight: bold;
      cursor: pointer;
      text-align: center;
    }

    .right-panel .links button:hover {
      background-color: #0033a0;
      color: #fff;
    }

    .radio-group {
      display: flex;
      gap: 1rem;
      margin-bottom: 1rem;
    }
  </style>
</head>
<body>
  <div class="left-panel">
    <h1>
      Tu <span>salud</span><br>
      es nuestra<br>
      prioridad
    </h1>
    <p>Regístrate para acceder a un cuidado médico personalizado y eficiente.</p>
  </div>
  <div class="right-panel">
    <!-- Formulario de inicio de sesión -->
    <form action="../controlador/autencontrolador.php" method="POST">
      <h2>Inicia sesión</h2>
      <div class="radio-group">
        <label><input type="radio" name="tipo_documento" value="DNI" checked> DNI</label>
        <label><input type="radio" name="tipo_documento" value="CE"> CE</label>
        <label><input type="radio" name="tipo_documento" value="Pasaporte"> Pasaporte</label>
      </div>
      <label for="numero_documento">Número de documento</label>
      <input type="text" id="numero_documento" name="numero_documento" placeholder="Número de documento" required>
      <label for="password">Contraseña</label>
      <input type="password" id="password" name="password" placeholder="Contraseña" required>
      <button type="submit">Iniciar sesión</button>
    </form>
    <div class="links">
      <button type="button" onclick="location.href='recuperar_contrasena.php'">Olvidaste tu contraseña</button>
      <button type="button" onclick="location.href='registro.php'">Regístrate</button>
    </div>
  </div>
</body>
</html>
