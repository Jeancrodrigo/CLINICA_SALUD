<?php
session_start();

if (!isset($_SESSION['usuario']) || $_SESSION['usuario']['rol'] !== 'paciente') {
    header("Location: login.php");
    exit();
}

$conexion = new mysqli("localhost", "root", "", "proyecto_web");
$id_paciente = $_SESSION['usuario']['id_usuario'];

// Obtener citas del paciente
$citas = $conexion->query("
  SELECT c.fecha_hora, m.nombre AS nombre_medico, m.apellido AS apellido_medico
  FROM citas c
  JOIN medico m ON c.id_medico = m.id_medico
  WHERE c.id_paciente = $id_paciente
");
?>

<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Mis Citas</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      padding: 20px;
      background: url('background-pattern.png') no-repeat center center fixed;
      background-size: cover;
    }

    .container {
      background-color: #fff;
      padding: 2rem;
      border-radius: 10px;
      box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
    }

    h1 {
      text-align: center;
      color: #007bff;
      margin-bottom: 1rem;
    }

    table {
      width: 100%;
      border-collapse: collapse;
      margin-top: 1rem;
    }

    th, td {
      padding: 10px;
      border: 1px solid #ddd;
    }

    th {
      background-color: #007bff;
      color: #fff;
    }
  </style>
</head>
<body>
  <div class="container">
    <h1>Mis Citas</h1>
    <table>
      <thead>
        <tr>
          <th>Fecha y Hora</th>
          <th>Médico</th>
        </tr>
      </thead>
      <tbody>
        <?php while ($row = $citas->fetch_assoc()): ?>
          <tr>
            <td><?= $row['fecha_hora']; ?></td>
            <td><?= $row['nombre_medico'] . ' ' . $row['apellido_medico']; ?></td>
          </tr>
        <?php endwhile; ?>
      </tbody>
    </table>
  </div>
</body>
</html>
