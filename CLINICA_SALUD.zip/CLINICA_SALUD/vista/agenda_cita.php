<?php
session_start();

// Verifica si el usuario ha iniciado sesión y es paciente
if (!isset($_SESSION['usuario']) || $_SESSION['usuario']['rol'] !== 'paciente') {
    header("Location: login.php");
    exit();
}

// Conexión a la base de datos
$conexion = new mysqli("localhost", "root", "", "proyecto_web");
if ($conexion->connect_error) {
    die("Error de conexión: " . $conexion->connect_error);
}

// Obtener médicos disponibles
$medicos = $conexion->query("SELECT id_medico, nombre, apellido FROM medico");
?>

<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Agendar Cita</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      display: flex;
      justify-content: center;
      align-items: center;
      height: 100vh;
      background: url('background-pattern.png') no-repeat center center fixed;
      background-size: cover;
    }

    .container {
      background-color: #fff;
      padding: 2rem;
      border-radius: 10px;
      box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
      width: 90%;
      max-width: 600px;
    }

    h1 {
      text-align: center;
      color: #007bff;
      margin-bottom: 1rem;
    }

    form {
      display: flex;
      flex-direction: column;
    }

    label {
      margin-bottom: 0.5rem;
      font-weight: bold;
    }

    input, select, button {
      padding: 0.8rem;
      margin-bottom: 1rem;
      border: 1px solid #ccc;
      border-radius: 5px;
    }

    button {
      background-color: #007bff;
      color: #fff;
      font-weight: bold;
      cursor: pointer;
    }

    button:hover {
      background-color: #0056b3;
    }
  </style>
</head>
<body>
  <div class="container">
    <h1>Agendar una Cita</h1>
    <form action="procesar_cita.php" method="POST">
      <label for="fecha">Fecha:</label>
      <input type="date" id="fecha" name="fecha" required>

      <label for="hora">Hora:</label>
      <input type="time" id="hora" name="hora" required>

      <label for="medico">Seleccionar Médico:</label>
      <select id="medico" name="id_medico" required>
        <option value="">Seleccionar Médico</option>
        <?php while ($row = $medicos->fetch_assoc()): ?>
          <option value="<?= $row['id_medico']; ?>">
            <?= $row['nombre'] . ' ' . $row['apellido']; ?>
          </option>
        <?php endwhile; ?>
      </select>

      <button type="submit">Agendar Cita</button>
    </form>
  </div>
</body>
</html>
